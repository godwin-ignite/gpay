<?php

/*
Plugin Name: WooCommerce - Googlepay WebConnect
Description: Tap WebConnect is a plugin provided by Googlepay Payments that enables Googlepay for Woocommerce Version 2.0.0 or greater version.
Version: 2.2
Author: Tap Payments
*/

add_action('plugins_loaded', 'woocommerce_gpay_init', 0);
//define tap payment padge location
define('gpay_imgdir', WP_PLUGIN_URL . "/" . plugin_basename(dirname(__FILE__)) . '/assets/img/');

//viewing the content of gpay template
function woocommerce_gpay_init(){
	if(!class_exists('WC_Payment_Gateway')) return;

    if( isset($_GET['msg']) && !empty($_GET['msg']) ){
        add_action('the_content', 'gpay_showMessage');
    }
    function gpay_showMessage($content){
            return '<div class="'.htmlentities(sanitize_text_field($_GET['type'])).'">'.htmlentities(urldecode(sanitize_text_field($_GET['msg']))).'</div>'.$content;
    }

    /**
     * Gateway class
     */
	class WC_gpay extends WC_Payment_Gateway{
		public function __construct(){
			$this->id 					= 'gpay';
			$this->method_title 		= 'gpay';
			$this->method_description	= "Pay via Googlepay; you can pay securely with your debit";
			$this->supports = array(
				'products',
				'refunds'
			);
			$this->has_fields 			= false;
			$this->init_form_fields();
			$this->init_settings();
			$this->icon = gpay_imgdir . 'gpay.png';
						
			$this->title 			= $this->settings['title'];
			//$this->redirect_page_id = $this->settings['redirect_page_id'];
			$this->test_public_key  = $this->settings['test_public_key'];
			$this->test_secret_key  = $this->settings['test_secret_key'];
			$this->live_public_key  = $this->settings['live_public_key'];
			$this->live_secret_key  = $this->settings['live_secret_key'];	
			$this->description 		= $this->settings['description'];	
			
			$this->msg['message'] 	= "";
			$this->msg['class'] 	= "";
					
			add_action('init', array(&$this, 'check_gpay_response'));
			//update for woocommerce >2.0
			add_action( 'woocommerce_api_' . strtolower( get_class( $this ) ), array( $this, 'check_gpay_response' ) );
			
			if ( version_compare( WOOCOMMERCE_VERSION, '2.0.0', '>=' ) ) {
				/* 2.0.0 */
				add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( &$this, 'process_admin_options' ) );
			} else {
				/* 1.6.6 */
				add_action( 'woocommerce_update_options_payment_gateways', array( &$this, 'process_admin_options' ) );
			}
			
			add_action('woocommerce_receipt_gpay', array(&$this, 'receipt_page'));
			add_action( 'woocommerce_api_taps_webhook', array( $this, 'webhook' ) );
		
		}
    
		function init_form_fields(){
			$this->form_fields = array(
				'enabled' => array(
					'title' 		=> __('Enable/Disable', 'kdc'),
					'type' 			=> 'checkbox',
					'label' 		=> __('Enable Tap Payment Module.', 'kdc'),
					'default' 		=> 'no',
					'description' 	=> 'Show in the Payment List as a payment option'
				),
      			'title' => array(
					'title' 		=> __('Title:', 'kdc'),
					'type'			=> 'text',
					'default' 		=> __('Googlepay', 'kdc'),
					'description' 	=> __('This controls the title which the user sees during checkout.', 'kdc'),
					'desc_tip' 		=> true
				),
      			'description' => array(
					'title' 		=> __('Description:', 'kdc'),
					'type' 			=> 'textarea',
					'default' 		=> __('pay via Tap/Googlepay; you can pay securely with your debit or credit card.', 'kdc'),
					'description' 	=> __('This controls the description which the user sees during checkout.', 'kdc'),
					'desc_tip' 		=> true
				),
      			'test_public_key' => array(
                    'title'       => __('Test Public Key', 'kdc'),
                    'type'        => 'text',
					          'value'       => '',
					          'description' => __( 'Get your Test Public Key from Tap.','woocommerce' ),
					          'default'     => '',
					          'desc_tip'    =>true,
                    'required'    =>true),
				'test_secret_key' => array(
                    'title'       => __('Test Secret Key', 'kdc'),
                    'type'        => 'text',
					          'value'       => '',
					          'description' => __( 'Get your Test Secret Key from Tap.','woocommerce' ),
					          'default'     => '',
					          'desc_tip'    =>true,
                    'required'    =>true),
				'live_secret_key' => array(
                    'title'       => __('Live Secret Key', 'kdc'),
                    'type'        => 'text',
					          'value'       => '',
					          'description' => __( 'Get your Live Secret Key from Tap.','woocommerce' ),
					          'default'     => '',
					          'desc_tip'    =>true,
                    'required'    =>true),
                'live_public_key' => array(
                    'title'       => __('Live Public Key', 'kdc'),
                    'type'        => 'text',
					          'value'       => '',
                    'description' => __( 'Get your Live Public Key from Tap.', 'woocommerce' ),
          					'default'     => '',
          					'desc_tip'    => true,
                    'required'    => true
                   ),
     //            'enableKnet' => array(
					// 'title' 		=> __('Enable Knet', 'kdc'),
					// 'type' 			=> 'checkbox',
					// 'label' 		=> __('Enable Tap Knet .', 'kdc'),
					// 'default' 		=> 'no',
					// 'description' 	=> __('Tick to run Knet on the Tap platform'),
					// 'desc_tip' 		=> true
     //            ),
     //            'enableBenefit' => array(
					// 'title' 		=> __('Enable Benefit', 'kdc'),
					// 'type' 			=> 'checkbox',
					// 'label' 		=> __('Enable Tap Benefit .', 'kdc'),
					// 'default' 		=> 'no',
					// 'description' 	=> __('Tick to run Benefit on the Tap platform'),
					// 'desc_tip' 		=> true
                //),
      			'testmode' => array(
					'title' 		=> __('TEST Mode', 'kdc'),
					'type' 			=> 'checkbox',
					'label' 		=> __('Enable Tap TEST Transactions.', 'kdc'),
					'default' 		=> 'no',
					'description' 	=> __('Tick to run TEST Transaction on the Tap platform'),
					'desc_tip' 		=> true
                ),
     //  			'redirect_page_id' => array(
					// 'title' 		=> __('Return Page'),
					// 'type' 			=> 'select',
					// 'options' 		=> $this->tap_get_pages('Select Page'),
					// 'description' 	=> __('URL of success page', 'kdc'),
					// 'desc_tip' 		=> true
     //            )
			);
		}


        /**
         * Admin Panel Options
         * - Options for bits like 'title' and availability on a country-by-country basis
         **/
		public function admin_options(){
			echo '<h3>'.__('Tap', 'kdc').'</h3>';
			echo '<p>'.__('Tap works by sending the user to Tap to enter their payment information.').'</p>';
			echo '<table class="form-table">';
			// Generate the HTML For the settings form.
			$this -> generate_settings_html();
			echo '</table>';
		}
        /**
         *  There are no payment fields for techpro, but we want to show the description if set.
         **/
		function payment_fields(){
			if($this->description) echo wpautop(wptexturize($this->description));
			echo '<ul class="woocommerce-PaymentMethods">';
            if ( $this->settings['enableKnet'] == "yes" ){
			echo '<input type="radio" name="payment_type" value="Knet" class="woocommerce-PaymentMethods"  checked="checked">Knet</li>';
		}
			if ( $this->settings['enableBenefit'] == "yes" ){
					echo '
					<li class="woocommerce-PaymentMethods"><input type="radio" name="payment_type" value="Benefit" class="woocommerce-PaymentMethods"  checked="checked">Benefit</li>';
				}
		}
		/**
		* Receipt Page
		**/
		function receipt_page($order){
			echo '<p>'.__('Thank you for your order, please click the button below to pay with Tap/Googlepay.', 'kdc').'</p>';
			echo $this->generate_gpay_form($order);
		}
		/**
		* Generate tap button link
		**/
		function generate_gpay_form($order_id){
			global $woocommerce;
			$order = new WC_Order( $order_id );
			$txnid = $order_id.'_'.date("ymds");
			$url = $order->get_checkout_order_received_url();
			if ( $this->redirect_page_id == "" || $this->redirect_page_id == 0 ) {
				$redirect_url = $order->get_checkout_order_received_url();
			} else {
				$redirect_url = get_permalink($this->redirect_page_id);
			}

			//For wooCoomerce 2.0
			if ( version_compare( WOOCOMMERCE_VERSION, '2.0.0', '>=' ) ) {
				$redirect_url = add_query_arg( 'wc-api', get_class( $this ), $redirect_url );
			}

			//$productinfo = "Order $order_id";

			//$str = "$this->merchant_id|$txnid|$order->order_total|$productinfo|$order->billing_first_name|$order->billing_email|$order_id||||||||||$this->salt";
			//$hash = strtolower(hash('sha512', $str));

			$gpay_args = array(
				'MEID' 			=> $this->test_public_key,
				'UName'			=> $this->test_secret_key,
				'PWD'			=> $this->live_public_key,
				'ItemName1'		=> 'Order ID : '.$txnid,
				'ItemQty1'		=> '1',
				'OrdID' 		=> $order_id,
				'ItemPrice1' 	=> $order->order_total,
				'CurrencyCode'	=> strtoupper(get_woocommerce_currency()),
				'CstFName'		=> $order->billing_first_name.' '.$order->billing_last_name,
				'CstEmail' 		=> $order->billing_email,
				'CstMobile' 	=> $order->billing_phone,
				'ReturnURL' 	=> $redirect_url
			);
			$gpay_args_array = array();
			foreach($gpay_args as $key => $value){
				$tap_args_array[] = "<input type='hidden' name='$key' value='$value'/>";
			}
			
			return '	<form action="'.$this->liveurl.'" method="post" id="gpay_payment_form">
  				' . implode('', $gpay_args_array) . '
				<input type="submit" class="button-alt" id="submit_gpay_payment_form" value="'.__('Pay via Googlepay/Tap', 'kdc').'" /> <a class="button cancel" href="'.$order->get_cancel_order_url().'">'.__('Cancel order &amp; restore cart', 'kdc').'</a>
					<script type="text/javascript">
					jQuery(function(){
					jQuery("body").block({
						message: "'.__('Thank you for your order. We are now redirecting you to Googlepay Payment Gateway to make payment.', 'kdc').'",
						overlayCSS: {
							background		: "#fff",
							opacity			: 0.6
						},
						css: {
							padding			: 20,
							textAlign		: "center",
							color			: "#555",
							border			: "3px solid #aaa",
							backgroundColor	: "#fff",
							cursor			: "wait",
							lineHeight		: "32px"
						}
					});
					jQuery("#submit_gpay_payment_form").click();});
					</script>
				</form>';
		}
		/**
		* Process the payment and return the result
		**/
		function process_payment($order_id){
			global $woocommerce;

			$order = wc_get_order($order_id);
                $currencyCode = $order->get_currency();
                $orderid = $order->get_id();
	 			$order_amount = $order->get_total();
	 			//var_dump($order_amount);exit;

	 			$table_prefix = $wpdb->prefix;
	 			
	 			
                if ( $this->settings['testmode'] == "yes" ){

	 				$active_sk = $this->test_secret_key;
	 				

	 				$active_pk = $this->test_public_key;

	 			}



	 			else {

	 				$active_sk = $this->live_secret_key;

	 				$active_pk = $this->live_public_key;
	 			}

               
                $charge_url = 'https://api.tap.company/v2/charges';

                //$first_name = $_POST['billing_first_name'];
                $first_name = isset($_POST['billing_first_name']) ? $_POST['billing_first_name'] : $order->get_billing_first_name();
                

                $last_name = isset($_POST['billing_last_name']) ? $_POST['billing_last_name'] : $order->get_billing_last_name();

                $country = isset($_POST['billing_country']) ? $_POST['billing_country'] : $order->get_billing_country();

                $city = isset($_POST['billing_city']) ? $_POST['billing_city'] : $order->get_billing_city();
 			
				$billing_address = isset($_POST['billing_address_1']) ? $_POST['billing_address_1'] : $order->get_billing_address_1();
                $url = $order->get_checkout_order_received_url();
			if ( $this->redirect_page_id == "" || $this->redirect_page_id == 0 ) {
				$redirect_url = $order->get_checkout_order_received_url();
			} else {
				$redirect_url = get_permalink($this->redirect_page_id);
			}

			//For wooCoomerce 2.0
			if ( version_compare( WOOCOMMERCE_VERSION, '2.0.0', '>=' ) ) {
				$redirect_url = add_query_arg( 'wc-api', get_class( $this ), $redirect_url );
			}
                $return_url = $redirect_url;
               // var_dump($return_url);exit;

                $billing_email = isset($_POST['billing_email']) ? $_POST['billing_email'] : $order->get_billing_email();

                $biliing_fone = $biliing_fone  = isset($_POST['billing_phone']) ? $_POST['billing_phone'] : $order->get_billing_phone();

                $avenue = isset($_POST['billing_address_2']) ? $_POST['billing_address_2'] : $order->get_billing_address_2();
				
                //$new_card = $_POST['woocommerce-SavedPaymentMethods-token'];
				
                $order_amount = $order->get_total();

                $radioVal = $_POST["payment_type"];

                    $source_id = 'src_google_pay';
        			$trans_object["amount"]                   = $order_amount;
        			$trans_object["currency"]                 = $currencyCode;
        			$trans_object["threeDsecure"]             = true;
        			$trans_object["save_card"]                = true;
        			$trans_object["description"]              = 'Test Description';
        			$trans_object["statement_descriptor"]     = 'Sample';
        			$trans_object["metadata"]["udf1"]          = 'test';
        			$trans_object["metadata"]["udf2"]          = 'test';
        			$trans_object["reference"]["transaction"]  = 'txn_0001';
        			$trans_object["reference"]["order"]        = $orderid;
        			$trans_object["receipt"]["email"]          = false;
        			$trans_object["receipt"]["sms"]            = true;
        			$trans_object["customer"]["first_name"]    = $first_name;
        			$trans_object["customer"]["last_name"]    = $last_name;
        			$trans_object["customer"]["email"]        = $billing_email;
        			$trans_object["customer"]["phone"]["country_code"]       = '965';
        			$trans_object["customer"]["phone"]["number"] = $biliing_fone;
        			$trans_object["source"]["id"] = $source_id;
        			$trans_object["post"]["url"] = get_site_url()."/wc-api/taps_webhook";
        			$trans_object["redirect"]["url"] = $return_url;
        			$frequest = json_encode($trans_object);
        			$frequest = stripslashes($frequest);


$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => $charge_url,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS => $frequest,
  CURLOPT_HTTPHEADER => array(
                            "authorization: Bearer ".$active_sk,
                            "content-type: application/json"
                ),
));

$response = curl_exec($curl);
$err = curl_error($curl);
$obj = json_decode($response);
$charge_id = $obj->id;
$redirct_Url = $obj->transaction->url;
                 return array(
						'result' => 'success',
						'redirect' => $redirct_Url
					);
		}
		/**
		* Check for valid Tap server callback
		**/
		function check_gpay_response(){
			global $woocommerce;

 			
			$charge_url = 'https://api.tap.company/v2/charges';
			if ( $this->settings['testmode'] == "yes" ){

	 				$active_sk = $this->test_secret_key;
	 			}
	 			else {

	 				$active_sk = $this->live_secret_key;
	 			}
			
			//echo ($charge_url);exit;
			$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.tap.company/v2/charges/".$_GET['tap_id'],
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_POSTFIELDS => "{}",
  CURLOPT_HTTPHEADER => array(
    "authorization: Bearer ".$active_sk,
  ),
));

$response = curl_exec($curl);
$obj = json_decode($response);
$order_id = $obj->reference->order;
$order = wc_get_order($order_id);
//var_dump($order);exit;
$response = json_decode($response);
//var_dump($response);exit;
if ($response->status == 'CAPTURED' && $response->post->status == 'ERROR') {
	//echo 'here';exit;
					$order->update_status('processing');
					$order->payment_complete($_GET['tap_id']);
					add_post_meta( $order->id, '_transaction_id', $_GET['tap_id'], true );
					
					$order->add_order_note(sanitize_text_field('Tap payment successful').("<br>").('ID').(':'). ($_GET['tap_id'].("<br>").('Payment Type :') . ($response->source->payment_method).("<br>").('Payment Ref:'). ($response->reference->payment)));
					$order->payment_complete($_GET['tap_id']);
					$woocommerce->cart->empty_cart();
				  $redirect_url = $order->get_checkout_order_received_url();
				 // echo $redirect_url;exit;
					wp_redirect($redirect_url);exit;
			}


				
				if ($response->status !== 'CAPTURED' && $response->post->status == 'ERROR'){
					$order->update_status('pending');
					$order->add_order_note(sanitize_text_field('Tap payment failed').("<br>").('ID').(':'). ($_GET['tap_id'].("<br>").('Payment Type :') . ($response->source->payment_method).("<br>").('Payment Ref:'). ($response->reference->payment)));
					$items = $order->get_items();
 					$cart_url = $woocommerce->cart->get_cart_url();
 						wp_redirect($cart_url);
 					//$this->$redirect_url;
 					//$failure_url = get_permalink($this->failer_page_id);
 					//wp_redirect($failure_url);
 					wc_add_notice( __('Transaction Failed ', 'woothemes') . $error_message, 'error' );
                   	return;
 					exit;


				}

					$err = curl_error($curl);

					curl_close($curl);

					if ($err) {
						echo "cURL Error #:" . $err;
					} else {
						echo $response->code;
					}
 				
 				if ($response->status !== 'CAPTURED' && $response->post->status == 'SUCCESS'){
 				    	$order->update_status('pending');
					$order->add_order_note(sanitize_text_field('Tap payment failed').("<br>").('ID').(':'). ($_GET['tap_id'].("<br>").('Payment Type :') . ($response->source->payment_method).("<br>").('Payment Ref:'). ($response->reference->payment)));
					$items = $order->get_items();
 					$cart_url = $woocommerce->cart->get_cart_url();
 						wp_redirect($cart_url);
 					wc_add_notice( __('Transaction Failed ', 'woothemes') . $error_message, 'error' );
                   return;
 					exit;
 				}
 				if($response->status == 'CAPTURED' && $response->post->status == 'SUCCESS'){
            		$redirect_url = $order->get_checkout_order_received_url();
					wp_redirect($redirect_url);exit;
}
					
 				}
 			public function webhook($order_id) {
	            $data = json_decode(file_get_contents("php://input"), true);
	            $headers = apache_request_headers();
	            $orderid = $data['reference']['order'];
	            $status = $data['status'];
	            $charge_id = $data['id'];
    
            if ($status == 'CAPTURED') {
	            $order = wc_get_order($orderid);
		        $order->payment_complete();
		        $order->add_order_note(sanitize_text_field('Tap payment successful...').("<br>").('ID').(':'). ($charge_id.("<br>").('Payment Type :') . ($data['source']['payment_method']).("<br>").('Payment Ref:'). ($data['reference']['payment'])));
		        $order->reduce_order_stock();
		         update_option('webhook_debug', $_GET);
            }
            if($status == 'DECLINED' || $response->status == 'CANCELLED' || $response->status == 'FAILED'){
               $order = wc_get_order($orderid);
               $order->update_status('pending');
	           $order->add_order_note(sanitize_text_field('Tap payment failed...').("<br>").('ID').(':'). ($charge_id.("<br>").('Payment Type :') . ($data['source']['payment_method']).("<br>").('Payment Ref:'). ($data['reference']['payment'])));
	           update_option('webhook_debug', $_GET);
	           	
            }

    }
		/*
        //Removed For WooCommerce 2.0
		function tap_showMessage($content){
			return '<div class="box '.$this->msg['class'].'">'.$this->msg['message'].'</div>'.$content;
		}
		*/
		
		// get all pages
		function gpay_get_pages($title = false, $indent = true) {
			$wp_pages = get_pages('sort_column=menu_order');
			$page_list = array();
			if ($title) $page_list[] = $title;
			foreach ($wp_pages as $page) {
				$prefix = '';
				// show indented child pages?
				if ($indent) {
                	$has_parent = $page->post_parent;
                	while($has_parent) {
                    	$prefix .=  ' - ';
                    	$next_page = get_post($has_parent);
                    	$has_parent = $next_page->post_parent;
                	}
            	}
            	// add to page list array array
            	$page_list[$page->ID] = $prefix . $page->post_title;
        	}
        	return $page_list;
    		}
    function process_refund($order_id, $amount = null, $reason = '')
		{
			global $post, $woocommerce;
			$order = new WC_Order($order_id);
			$transID = get_post_meta( $order->id, '_transaction_id');
			$currency = $order->currency;
	 		$refund_url = 'https://api.tap.company/v2/refunds';
	 		$refund_request['charge_id'] = $transID;
	 		$refund_request['amount'] = $amount;
	 		$refund_request['currency'] = $currency;
	 		$refund_request['description'] = "Description";
	 		$refund_request['reason'] = $reason;
            $refund_request['reference']['merchant']  = "txn_0001";	 
	        $refund_request['metadata']['udf1']= "test1";
	        $refund_request['metadata']['udf2']= "test2";
	        $refund_request['post']['url']  = "http://your_url.com/post";
	 		$json_request = json_encode($refund_request);
	 		$json_request = str_replace( '\/', '/', $json_request );
	 		$json_request = str_replace(array('[',']'),'',$json_request);
//print_r($json_request);exit;

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.tap.company/v2/refunds",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS =>$json_request,
  CURLOPT_HTTPHEADER => array(
				    		"authorization: Bearer ".$this->live_secret_key,
				    		"content-type: application/json"
			  		),
));

$response = curl_exec($curl);;
//print_r($response);exit;
	 		$response = json_decode($response);
	 		if ($response->id) {
	 			if ( $response->status == 'PENDING') {
	 				$order->add_order_note(sanitize_text_field('Tap Refund successful').("<br>").'Refund ID'.("<br>"). $response->id);
	 						return true;
	 			}
	 		}
	 		else { 
	 			return false;
	 		}
		}
		}
		/**
		* Add the Gateway to WooCommerce
		**/
		function woocommerce_add_gpay_gateway($methods) {
			$methods[] = 'WC_gpay';
			return $methods;
		}

		add_filter('woocommerce_payment_gateways', 'woocommerce_add_gpay_gateway' );
	}





	add_action('woocommerce_blocks_loaded', 'woocommerce_gateway_gpay_woocommerce_block_support');

function woocommerce_gateway_gpay_woocommerce_block_support() {
	if ( class_exists( 'Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType' ) ) {
		require_once dirname( __FILE__ ) . '/class-wc-gpay-blocks-support.php';
		add_action(
			'woocommerce_blocks_payment_method_type_registration',
			function( Automattic\WooCommerce\Blocks\Payments\PaymentMethodRegistry $payment_method_registry ) {

				$container = Automattic\WooCommerce\Blocks\Package::container();
				// registers as shared instance.
				$container->register(
					WC_gpay_Blocks_Support::class,
					function(Automattic\WooCommerce\Blocks\Registry\Container $container) {
						$asset_api = $container->get( Automattic\WooCommerce\Blocks\Assets\Api::class );
						return new WC_gpay_Blocks_Support($asset_api);
					}
				);
				$payment_method_registry->register(
					$container->get( WC_gpay_Blocks_Support::class )
				);
			},
		);
	}
}

