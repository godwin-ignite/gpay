=== Tap Payment Gateway ===
Contributors: Tap Payments
Donate link: 
Tags: Payments, Kuwait, Online Payment, Tap, goSell
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Online Payment Gateway

== Description ==

Using this plugin WP/WooCommerce website owners in Kuwait and many other countries in the World can start receiving online payments from their clients, payments can be received via Visa, MasterCard, Amex or K-Net (The Kuwaiti Online Payment Gateway).

== Installation ==

1-With your FTP program, upload the plugin folder after you extract it to the wp-content/plugins folder in WordPress directory.
2-Go to plugins screen and find the newly uploaded plugin in the list, click on Activate to activate the plugin.
3-Use the below API credentials (Test Credentails):
	a.Merchant ID: 13014
	b.Username: test
	c.Password: tap1234
	d.API Key: 1tap7
4- Once you're done with testing, please contact us to provide you with you live API credentials. 

== Frequently asked questions ==

= How will you manage payouts? =

We will transfer your money to your bank account.

= How can I get my live API credentials? =

Register your business on our website www.tap.company and then we will be contacting you sharing your API credentials.

== Screenshots ==

1. /assets/screenshots/goSell.png
2. /assets/screenshots/SShot1.PNG
3. /assets/screenshots/SShot2.PNG
4. /assets/screenshots/SShot3.PNG
5. /assets/screenshots/SShot4.PNG
6. /assets/screenshots/SShot5.PNG



